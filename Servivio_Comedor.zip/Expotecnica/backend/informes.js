// Comparte los límites que ya utiliza /solicitud/:cedula.
function categoria(s) {
  const familia = s.grupoFamiliar || [];
  if (!familia.length) return 'Sin información';
  if (familia.some(p => p.ingresoMensual === '' || p.ingresoMensual == null || !Number.isFinite(Number(p.ingresoMensual)) || Number(p.ingresoMensual) < 0)) return 'Sin información';
  const ingreso = familia.reduce((n, p) => n + Number(p.ingresoMensual), 0) / familia.length;
  return ingreso < 50527 ? 'Pobreza extrema' : ingreso <= 108084 ? 'Pobreza' : ingreso <= 151317 ? 'Vulnerabilidad' : 'No pobre';
}
function preparar(solicitudes) {
  return solicitudes.map(s => {
    const d = s.datosSolicitante || {};
    const seccion = String(d.seccion || '').trim();
    const nivel = /^(7|8|9|10|11|12)(?:\s*-|$)/.exec(seccion)?.[1] || 'Sin nivel';
    return { nombre: d.nombreCompleto || '', cedula: String(d.identificacion || ''), seccion, nivel,
      genero: d.genero || '', categoria: categoria(s), estado: s.estadoSolicitud || 'Pendiente' };
  });
}
module.exports = { categoria, preparar };
