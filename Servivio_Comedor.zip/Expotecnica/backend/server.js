require("dns").setDefaultResultOrder("ipv4first");

const express = require("express");
const { MongoClient } = require("mongodb");
const cors = require("cors");
const multer = require("multer");
const nodemailer = require("nodemailer");
const bcrypt = require("bcrypt");
const ExcelJS = require("exceljs");

require("dotenv").config();

const app = express();

const upload = multer({ dest: "uploads/" });

app.use(cors());
app.use(express.json());

const url = process.env.MONGO_URI;

const client = new MongoClient(url);

let db;

async function conectarDB() {

    await client.connect();

    console.log("Conectado a MongoDB Local");

    db = client.db("BD-Comedor");
}

function generarPassword() {

    const caracteres =
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

    let password = "";

    for (let i = 0; i < 8; i++) {

        password += caracteres.charAt(
            Math.floor(Math.random() * caracteres.length)
        );
    }

    return password;
}

const transporter = nodemailer.createTransport({

    service: "gmail",

    auth: {

        user: process.env.EMAIL_USER,

        pass: process.env.EMAIL_PASS
    }
});

function normalizarTexto(texto) {

    return texto
        .toLowerCase()
        .normalize("NFD")
        .replace(/[\u0300-\u036f]/g, "")
        .replace(/\s+/g, " ")
        .trim();
}

app.post("/registro", async (req, res) => {

    try {

        const { nombre, cedula } = req.body;

        const estudiantes = await db.collection("estudiantes").find({

            cedula: cedula.trim()

        }).toArray();

        const estudiante = estudiantes.find(est => {

            const textoBD = normalizarTexto(est.nombre);

            const textoIngresado = normalizarTexto(nombre);

            const palabrasBD = textoBD.split(" ");

            const palabrasIngresadas = textoIngresado.split(" ");

            const nombresCoinciden = palabrasIngresadas.every(palabra =>
                palabrasBD.includes(palabra)
            );

            return (

                nombresCoinciden &&
                String(est.cedula).trim() === String(cedula).trim()
            );
        });

        if (!estudiante) {

            return res.status(404).json({

                mensaje: "Estudiante no autorizado"
            });
        }

        const existeUsuario = await db.collection("usuarios").findOne({

            cedula: cedula
        });

        if (existeUsuario) {

            return res.json({

                mensaje: "El usuario ya está registrado"
            });
        }

        const password = generarPassword();

        const passwordHash = await bcrypt.hash(password, 10);

        await db.collection("usuarios").insertOne({

            nombre: estudiante.nombre,
            cedula: estudiante.cedula,
            correo: estudiante.correoPadre,
            password: passwordHash
        });

        await transporter.sendMail({

            from: process.env.EMAIL_USER,

            to: estudiante.correoPadre,

            subject: "Acceso al sistema de comedor",

            text:
                `Hola.\n\n` +
                `Su contraseña de acceso es: ${password}\n\n` +
                `Utilice esta contraseña para ingresar al sistema.`
        });

        res.json({

            mensaje: "Registro exitoso. Revise el correo del encargado."
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error en el registro"
        });
    }
});

app.post("/registro-docente", async (req, res) => {

    try {

        const { nombre, cedula } = req.body;

        const docentes = await db.collection("docentes").find({

            cedula: cedula.trim()

        }).toArray();

        const docente = docentes.find(doc => {

            const textoBD = normalizarTexto(doc.nombre);

            const textoIngresado = normalizarTexto(nombre);

            const palabrasBD = textoBD.split(" ");

            const palabrasIngresadas = textoIngresado.split(" ");

            const nombresCoinciden = palabrasIngresadas.every(palabra =>
                palabrasBD.includes(palabra)
            );

            return (

                nombresCoinciden &&
                String(doc.cedula).trim() === String(cedula).trim()
            );
        });

        if (!docente) {

            return res.status(404).json({

                mensaje: "Docente no autorizado"
            });
        }

        const existeUsuario = await db.collection("usuariosDocentes").findOne({

            cedula: cedula
        });

        if (existeUsuario) {

            return res.json({

                mensaje: "El docente ya está registrado"
            });
        }

        const password = generarPassword();

        const passwordHash = await bcrypt.hash(password, 10);

        await db.collection("usuariosDocentes").insertOne({

            nombre: docente.nombre,
            cedula: docente.cedula,
            correo: docente.correo,
            password: passwordHash
        });

        await transporter.sendMail({

            from: process.env.EMAIL_USER,

            to: docente.correo,

            subject: "Acceso docente al sistema",

            text:
                `Hola.\n\n` +
                `Su contraseña de acceso es: ${password}\n\n` +
                `Utilice esta contraseña para ingresar al sistema.`
        });

        res.json({

            mensaje: "Registro exitoso. Revise su correo."
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error en el registro"
        });
    }
});

app.post("/login", async (req, res) => {

    try {

        const { cedula, password } = req.body;

        const usuario = await db.collection("usuarios").findOne({

            cedula: cedula.trim()
        });

        if (!usuario) {

            return res.status(404).json({

                mensaje: "Usuario no encontrado"
            });
        }

        const coincide = await bcrypt.compare(

            password,
            usuario.password
        );

        if (!coincide) {

            return res.status(401).json({

                mensaje: "Contraseña incorrecta"
            });
        }

        const solicitud = await db.collection("solicitudes").findOne({

            "datosSolicitante.identificacion": usuario.cedula
        });

        res.json({

            mensaje: "Inicio de sesión correcto",

            usuario: {

                nombre: usuario.nombre,
                cedula: usuario.cedula
            },

            solicitud: solicitud || null
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error al iniciar sesión"
        });
    }
});
app.post("/login-docente", async (req, res) => {

    try {

        const { cedulaDocente, password } = req.body;

        const usuario = await db.collection("usuariosDocentes").findOne({

            cedula: cedulaDocente.trim()
        });

        if (!usuario) {

            return res.status(404).json({

                mensaje: "Docente no encontrado"
            });
        }

        const coincide = await bcrypt.compare(

            password,
            usuario.password
        );

        if (!coincide) {

            return res.status(401).json({

                mensaje: "Contraseña incorrecta"
            });
        }

        res.json({

            mensaje: "Inicio de sesión correcto",

            usuario: {

                nombre: usuario.nombre,
                cedula: usuario.cedula
            }
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error al iniciar sesión"
        });
    }
});

app.post("/solicitudes", upload.any(), async (req, res) => {

    try {

        const datos = JSON.parse(req.body.datos);

        datos.archivos = (req.files || []).map(file => ({

            nombreOriginal: file.originalname,
            nombreGuardado: file.filename
        }));

       const existeSolicitud =
await db.collection("solicitudes").findOne({

    "datosSolicitante.identificacion":
    datos.datosSolicitante.identificacion
});

if (existeSolicitud) {

    datos.estadoSolicitud = "Corregida";

    datos.corregida = true;

    datos.camposCorregidos =
        existeSolicitud.camposCorregir || [];

    datos.camposCorregir =
        existeSolicitud.camposCorregir || [];

    datos.observaciones = "";

    await db.collection("solicitudes").updateOne(

        {
            "datosSolicitante.identificacion":
            datos.datosSolicitante.identificacion
        },

        {
            $set: datos
        }
    );



} else {
    datos.estadoSolicitud = "Pendiente";

    await db.collection("solicitudes").insertOne(datos);
}

        await transporter.sendMail({

            from: process.env.EMAIL_USER,

            to: datos.datosEncargado.correoElectronico,

            subject: "Solicitud de comedor enviada",

            text:
                `Hola.\n\n` +
                `La solicitud del beneficio de comedor estudiantil fue enviada correctamente.\n\n` +
                `La solicitud queda en espera de revisión por parte de la institución.\n\n` +
                `Gracias por utilizar el sistema.`
        });

        return res.json({

            mensaje: "Solicitud guardada correctamente"
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error al guardar"
        });
    }
});

app.get("/solicitud/:cedula", async (req, res) => {
    console.log("Cedula buscada:", req.params.cedula);

    try {

        const cedula = req.params.cedula;

        const solicitud = await db.collection("solicitudes").findOne({

            "datosSolicitante.identificacion": cedula
        });

        if (!solicitud) {

            return res.status(404).json({

                mensaje: "Solicitud no encontrada"
            });
        }

        const integrantes = solicitud.grupoFamiliar || [];

        let totalIngresos = 0;

        integrantes.forEach(integrante => {

            totalIngresos += Number(
                integrante.ingresoMensual
            ) || 0;
        });

        const cantidadIntegrantes = integrantes.length;

        const perCapita =
            cantidadIntegrantes > 0
                ? totalIngresos / cantidadIntegrantes
                : 0;

        let clasificacion = "Pendiente";

        if (perCapita < 50527) {

            clasificacion = "Pobreza extrema";

        } else if (perCapita <= 108084) {

            clasificacion = "Pobreza";

        } else if (perCapita <= 151317) {

            clasificacion = "Vulnerabilidad";

        } else {

            clasificacion = "No pobre";
        }

        solicitud.calculoSocioeconomico = {

            totalIngresos,
            cantidadIntegrantes,
            ingresoPerCapita: perCapita,
            clasificacion
        };

        res.json(solicitud);

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error al obtener la solicitud"
        });
    }
});

app.get("/estado-solicitud/:cedula", async (req, res) => {

    try {

        const cedula = req.params.cedula;

        const solicitud =
        await db.collection("solicitudes").findOne({

            "datosSolicitante.identificacion":
            cedula
        });

        if (!solicitud) {

            return res.json({

                estado: "Sin solicitud"
            });
        }

        res.json({

            estado:
            solicitud.estadoSolicitud
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje:
            "Error al obtener estado"
        });
    }
});

app.get("/solicitud-edicion/:cedula", async (req, res) => {

    try {

        const cedula = req.params.cedula;

        const solicitud =
        await db.collection("solicitudes").findOne({

            "datosSolicitante.identificacion":
            cedula
        });

        if (!solicitud) {

            return res.status(404).json({

                mensaje: "Solicitud no encontrada"
            });
        }

        res.json(solicitud);

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error al obtener solicitud"
        });
    }
});

app.post("/guardar-resolucion", async (req, res) => {

    try {

        const {

    cedula,
    estado,
    observaciones,
    camposCorregir

} = req.body;
        const solicitud = await db.collection("solicitudes").findOne({

            "datosSolicitante.identificacion": cedula
        });

        if (!solicitud) {

            return res.status(404).json({

                mensaje: "Solicitud no encontrada"
            });
        }

        await db.collection("solicitudes").updateOne(

            {
                "datosSolicitante.identificacion": cedula
            },

            {
                $set: {

    estadoSolicitud: estado,
    observaciones: observaciones,
    camposCorregir: camposCorregir

}
            }
        );

let mensajeCorreo = "";

if (estado === "Corrección pendiente") {

    mensajeCorreo =
        `Hola.\n\n` +
        `La solicitud de comedor estudiantil requiere correcciones.\n\n` +
        `Observaciones:\n${observaciones}\n\n` +
        `Por favor ingrese nuevamente al sistema, corrija la información indicada y vuelva a enviar la solicitud.\n\n` +
        `Gracias.`;

} else {

    mensajeCorreo =
        `Hola.\n\n` +
        `La solicitud del beneficio de comedor estudiantil ha sido revisada.\n\n` +
        `Estado: ${estado}\n\n` +
        `Observaciones: ${observaciones || "Sin observaciones"}\n\n` +
        `Gracias por utilizar el sistema.`;
}

await transporter.sendMail({

    from: process.env.EMAIL_USER,

    to: solicitud.datosEncargado.correoElectronico,

    subject: "Estado de solicitud de comedor estudiantil",

    text: mensajeCorreo
});

        res.json({

            mensaje: "Resolución guardada y correo enviado"
        });

    } catch (error) {

        console.log(error);

        res.status(500).json({

            mensaje: "Error al guardar la resolución"
        });
    }
});
/* =========================================================
   EXPORTAR TODAS LAS SOLICITUDES A EXCEL
========================================================= */

app.get("/exportar-excel", async (req, res) => {

    try {

        /* =========================================
           1. OBTENER SOLICITUDES DE MONGODB
        ========================================= */

        const solicitudes =
            await db
                .collection("solicitudes")
                .find({})
                .toArray();


        /* =========================================
           2. ORDENAR ESTUDIANTES ALFABÉTICAMENTE
        ========================================= */

        solicitudes.sort((a, b) => {

            const nombreA =
                a.datosSolicitante?.nombreCompleto || "";

            const nombreB =
                b.datosSolicitante?.nombreCompleto || "";

            return nombreA.localeCompare(
                nombreB,
                "es",
                {
                    sensitivity: "base"
                }
            );

        });


        /* =========================================
           3. CREAR LIBRO DE EXCEL
        ========================================= */

        const workbook =
            new ExcelJS.Workbook();


        workbook.creator =
            "Colegio Técnico Profesional Cañas";

        workbook.created =
            new Date();


        /* =====================================================
           HOJA 1 - SOLICITUDES
        ===================================================== */

        const hojaSolicitudes =
            workbook.addWorksheet(
                "Solicitudes"
            );


        hojaSolicitudes.views = [
            {
                state: "frozen",
                ySplit: 1
            }
        ];


        hojaSolicitudes.columns = [

            {
                header: "N°",
                key: "numero",
                width: 7
            },

            {
                header: "Nombre del estudiante",
                key: "nombre",
                width: 32
            },

            {
                header: "Cédula",
                key: "cedula",
                width: 18
            },

            {
                header: "Género",
                key: "genero",
                width: 15
            },

            {
                header: "Nacionalidad",
                key: "nacionalidad",
                width: 18
            },

            {
                header: "Edad",
                key: "edad",
                width: 10
            },

            {
                header: "Fecha de nacimiento",
                key: "fechaNacimiento",
                width: 20
            },

            {
                header: "Teléfono estudiante",
                key: "telefono",
                width: 18
            },

            {
                header: "Sección",
                key: "seccion",
                width: 12
            },

            {
                header: "Encargado legal",
                key: "encargado",
                width: 32
            },

            {
                header: "Cédula encargado",
                key: "cedulaEncargado",
                width: 18
            },

            {
                header: "Teléfono encargado",
                key: "telefonoEncargado",
                width: 18
            },

            {
                header: "Correo encargado",
                key: "correo",
                width: 32
            },

            {
                header: "Provincia",
                key: "provincia",
                width: 18
            },

            {
                header: "Cantón",
                key: "canton",
                width: 18
            },

            {
                header: "Distrito",
                key: "distrito",
                width: 18
            },

            {
                header: "Comunidad",
                key: "comunidad",
                width: 24
            },

            {
                header: "Dirección exacta",
                key: "direccion",
                width: 45
            },

            {
                header: "Distancia al colegio (km)",
                key: "distancia",
                width: 22
            },

            {
                header: "Total ingresos",
                key: "totalIngresos",
                width: 18
            },

            {
                header: "Cantidad integrantes",
                key: "cantidadIntegrantes",
                width: 20
            },

            {
                header: "Ingreso per cápita",
                key: "perCapita",
                width: 20
            },

            {
                header: "Estado de solicitud",
                key: "estado",
                width: 22
            },

            {
                header: "Fecha de registro",
                key: "fechaRegistro",
                width: 22
            }

        ];


        /* =========================================
           AGREGAR ESTUDIANTES
        ========================================= */

        solicitudes.forEach(
            (solicitud, index) => {

                const familiares =
                    solicitud.grupoFamiliar || [];


                const totalIngresos =
                    familiares.reduce(
                        (total, persona) => {

                            return total +
                                (
                                    Number(
                                        persona.ingresoMensual
                                    ) || 0
                                );

                        },
                        0
                    );


                const cantidadIntegrantes =
                    familiares.length;


                const perCapita =
                    cantidadIntegrantes > 0

                        ? totalIngresos /
                          cantidadIntegrantes

                        : 0;


                let fechaRegistro = "";


                if (solicitud.fechaRegistro) {

                    const fecha =
                        new Date(
                            solicitud.fechaRegistro
                        );


                    if (
                        !Number.isNaN(
                            fecha.getTime()
                        )
                    ) {

                        fechaRegistro =
                            fecha.toLocaleDateString(
                                "es-CR"
                            );

                    }

                }


                hojaSolicitudes.addRow({

                    numero:
                        index + 1,

                    nombre:
                        solicitud
                            .datosSolicitante
                            ?.nombreCompleto || "",

                    cedula:
                        solicitud
                            .datosSolicitante
                            ?.identificacion || "",

                    genero:
                        solicitud
                            .datosSolicitante
                            ?.genero || "",

                    nacionalidad:
                        solicitud
                            .datosSolicitante
                            ?.nacionalidad || "",

                    edad:
                        solicitud
                            .datosSolicitante
                            ?.edad || "",

                    fechaNacimiento:
                        solicitud
                            .datosSolicitante
                            ?.fechaNacimiento || "",

                    telefono:
                        solicitud
                            .datosSolicitante
                            ?.telefono || "",

                    seccion:
                        solicitud
                            .datosSolicitante
                            ?.seccion || "",


                    encargado:
                        solicitud
                            .datosEncargado
                            ?.nombreCompleto || "",

                    cedulaEncargado:
                        solicitud
                            .datosEncargado
                            ?.identificacion || "",

                    telefonoEncargado:
                        solicitud
                            .datosEncargado
                            ?.telefono || "",

                    correo:
                        solicitud
                            .datosEncargado
                            ?.correoElectronico || "",


                    provincia:
                        solicitud
                            .direccionGrupoFamiliar
                            ?.provincia || "",

                    canton:
                        solicitud
                            .direccionGrupoFamiliar
                            ?.canton || "",

                    distrito:
                        solicitud
                            .direccionGrupoFamiliar
                            ?.distrito || "",

                    comunidad:
                        solicitud
                            .direccionGrupoFamiliar
                            ?.comunidad || "",

                    direccion:
                        solicitud
                            .direccionGrupoFamiliar
                            ?.direccionExacta || "",

                    distancia:
                        solicitud
                            .direccionGrupoFamiliar
                            ?.distanciaKm || 0,


                    totalIngresos:
                        totalIngresos,

                    cantidadIntegrantes:
                        cantidadIntegrantes,

                    perCapita:
                        Math.round(
                            perCapita
                        ),

                    estado:
                        solicitud
                            .estadoSolicitud ||
                        "Pendiente",

                    fechaRegistro:
                        fechaRegistro

                });

            }
        );


        /* =====================================================
           HOJA 2 - GRUPO FAMILIAR
        ===================================================== */

        const hojaFamilia =
            workbook.addWorksheet(
                "Grupo Familiar"
            );


        hojaFamilia.views = [
            {
                state: "frozen",
                ySplit: 1
            }
        ];


        hojaFamilia.columns = [

            {
                header: "Estudiante",
                key: "estudiante",
                width: 32
            },

            {
                header: "Cédula estudiante",
                key: "cedulaEstudiante",
                width: 20
            },

            {
                header: "Nombre del familiar",
                key: "nombre",
                width: 32
            },

            {
                header: "Cédula",
                key: "cedula",
                width: 18
            },

            {
                header: "Edad",
                key: "edad",
                width: 10
            },

            {
                header: "Parentesco",
                key: "parentesco",
                width: 18
            },

            {
                header: "Escolaridad",
                key: "escolaridad",
                width: 22
            },

            {
                header: "Ocupación",
                key: "ocupacion",
                width: 25
            },

            {
                header: "Ingreso mensual",
                key: "ingreso",
                width: 20
            }

        ];


        solicitudes.forEach(
            solicitud => {

                const nombreEstudiante =
                    solicitud
                        .datosSolicitante
                        ?.nombreCompleto || "";


                const cedulaEstudiante =
                    solicitud
                        .datosSolicitante
                        ?.identificacion || "";


                const familiares =
                    solicitud.grupoFamiliar || [];


                familiares.forEach(
                    persona => {

                        hojaFamilia.addRow({

                            estudiante:
                                nombreEstudiante,

                            cedulaEstudiante:
                                cedulaEstudiante,

                            nombre:
                                persona
                                    .nombreCompleto || "",

                            cedula:
                                persona.cedula || "",

                            edad:
                                persona.edad || "",

                            parentesco:
                                persona
                                    .parentesco || "",

                            escolaridad:
                                persona
                                    .escolaridad || "",

                            ocupacion:
                                persona
                                    .ocupacion || "",

                            ingreso:
                                Number(
                                    persona
                                        .ingresoMensual
                                ) || 0

                        });

                    }
                );

            }
        );


        /* =====================================================
           HOJA 3 - AYUDAS DEL ESTADO
        ===================================================== */

        const hojaAyudas =
            workbook.addWorksheet(
                "Ayudas del Estado"
            );


        hojaAyudas.views = [
            {
                state: "frozen",
                ySplit: 1
            }
        ];


        hojaAyudas.columns = [

            {
                header: "Estudiante",
                key: "estudiante",
                width: 32
            },

            {
                header: "Cédula estudiante",
                key: "cedulaEstudiante",
                width: 20
            },

            {
                header: "¿Recibe ayuda?",
                key: "recibe",
                width: 18
            },

            {
                header: "Persona beneficiaria",
                key: "persona",
                width: 30
            },

            {
                header: "Tipo de ayuda",
                key: "tipo",
                width: 20
            },

            {
                header: "Monto",
                key: "monto",
                width: 18
            },

            {
                header: "Detalle",
                key: "detalle",
                width: 35
            }

        ];


        solicitudes.forEach(
            solicitud => {

                const nombreEstudiante =
                    solicitud
                        .datosSolicitante
                        ?.nombreCompleto || "";


                const cedulaEstudiante =
                    solicitud
                        .datosSolicitante
                        ?.identificacion || "";


                const ayudas =
                    solicitud
                        .ayudasEstadoSolicitante ||
                    [];


                ayudas.forEach(
                    ayuda => {

                        hojaAyudas.addRow({

                            estudiante:
                                nombreEstudiante,

                            cedulaEstudiante:
                                cedulaEstudiante,

                            recibe:
                                ayuda
                                    .recibeAyuda || "",

                            persona:
                                ayuda
                                    .nombrePersona || "",

                            tipo:
                                ayuda
                                    .tipoAyuda || "",

                            monto:
                                Number(
                                    ayuda.monto
                                ) || 0,

                            detalle:
                                ayuda.detalle || ""

                        });

                    }
                );

            }
        );


        /* =====================================================
           ESTILO DE LAS TRES HOJAS
        ===================================================== */

        const hojas = [

            hojaSolicitudes,
            hojaFamilia,
            hojaAyudas

        ];


        hojas.forEach(hoja => {

            /* ENCABEZADO */

            hoja.getRow(1).font = {

                bold: true,

                color: {
                    argb: "FFFFFFFF"
                }

            };


            hoja.getRow(1).fill = {

                type: "pattern",

                pattern: "solid",

                fgColor: {
                    argb: "FF0F607A"
                }

            };


            hoja.getRow(1).alignment = {

                vertical: "middle",

                horizontal: "center"

            };


            hoja.getRow(1).height = 30;


            /* BORDES Y ALINEACIÓN */

            hoja.eachRow(row => {

                row.eachCell(cell => {

                    cell.alignment = {

                        vertical: "top",

                        wrapText: true

                    };


                    cell.border = {

                        top: {
                            style: "thin",
                            color: {
                                argb: "FFD8D8D8"
                            }
                        },

                        left: {
                            style: "thin",
                            color: {
                                argb: "FFD8D8D8"
                            }
                        },

                        bottom: {
                            style: "thin",
                            color: {
                                argb: "FFD8D8D8"
                            }
                        },

                        right: {
                            style: "thin",
                            color: {
                                argb: "FFD8D8D8"
                            }
                        }

                    };

                });

            });

        });


        /* =========================================
           FORMATO DE DINERO
        ========================================= */

        hojaSolicitudes
            .getColumn("totalIngresos")
            .numFmt =
            '₡#,##0';


        hojaSolicitudes
            .getColumn("perCapita")
            .numFmt =
            '₡#,##0';


        hojaFamilia
            .getColumn("ingreso")
            .numFmt =
            '₡#,##0';


        hojaAyudas
            .getColumn("monto")
            .numFmt =
            '₡#,##0';


        /* =====================================================
           4. CREAR EL ARCHIVO
        ===================================================== */

        const buffer =
            await workbook.xlsx.writeBuffer();


        /* =========================================
           5. ENVIARLO AL NAVEGADOR
        ========================================= */

        res.setHeader(
            "Content-Type",
            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
        );


        res.setHeader(
            "Content-Disposition",
            'attachment; filename="Solicitudes_Comedor_2026.xlsx"'
        );


        res.send(
            Buffer.from(buffer)
        );


    } catch (error) {

        console.error(
            "Error generando Excel:",
            error
        );


        res.status(500).json({

            mensaje:
                "Error al generar el archivo Excel"

        });

    }

});
// Informes: validar las credenciales docentes antes de consultar datos personales.
app.post('/informes-comedor', async (req, res) => {
    try {
        const { cedula, password } = req.body;
        if (typeof cedula !== 'string' || typeof password !== 'string') return res.status(400).json({mensaje:'Complete las credenciales docentes'});
        const usuario = await db.collection('usuariosDocentes').findOne({cedula:cedula.trim()});
        if (!usuario || !await bcrypt.compare(password, usuario.password)) return res.status(401).json({mensaje:'Credenciales docentes incorrectas'});
        const solicitudes = await db.collection('solicitudes').find({}).toArray();
        res.setHeader('Cache-Control', 'no-store');
        res.json({docente:usuario.nombre, registros:require('./informes').preparar(solicitudes)});
    } catch (error) {
        res.status(500).json({mensaje:'No se pudieron cargar los informes'});
    }
});

conectarDB().then(() => {

    app.listen(3000, () => {

        console.log("Servidor iniciado en puerto 3000");
    });
});